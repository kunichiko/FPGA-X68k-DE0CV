/*
 * spi.c
 */

#include "spi.h"

int speedflag;
alt_u32 spibase;

void spi_init(void){
	//disable interrupt
	IOWR_ALTERA_AVALON_SPI_CONTROL(SPI_SLOW_BASE, 0);
	IOWR_ALTERA_AVALON_SPI_CONTROL(SPI_FAST_BASE, 0);
	//set to slow
	spi_speed(0);
	//set CS to 'H'
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SDCS_BASE,1);
}

void spi_speed(int flag){
	if(flag){
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_SPIHS_BASE,1);
		spibase=SPI_FAST_BASE;
	}else{
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_SPIHS_BASE,0);
		spibase=SPI_SLOW_BASE;
	}
}

void spi_waitemp(void){
	alt_u32 status;
	do{
		status = IORD_ALTERA_AVALON_SPI_STATUS(spibase);
	}while((status & ALTERA_AVALON_SPI_STATUS_TMT_MSK)==0);
}

void spi_blank(int times){
	int i;
	spi_waitemp();
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SDCS_BASE,1);
	IOWR_ALTERA_AVALON_SPI_SLAVE_SEL(spibase,0x00);
	for(i=0;i<times;i++){
		IOWR_ALTERA_AVALON_SPI_TXDATA(spibase,0xff);
		spi_waitemp();
	}
}

char spi_tx(char data){
	alt_u32 udata,status;
	spi_waitemp();
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_SDCS_BASE,0);
	IOWR_ALTERA_AVALON_SPI_SLAVE_SEL(spibase,0x01);
	udata=(alt_u32)data;
	IOWR_ALTERA_AVALON_SPI_TXDATA(spibase,udata);
	spi_waitemp();
	do{
		status=IORD_ALTERA_AVALON_SPI_STATUS(spibase);
	}while((status & ALTERA_AVALON_SPI_STATUS_RRDY_MSK)==0);
	return (char)IORD_ALTERA_AVALON_SPI_RXDATA(spibase);
}

int spi_txstr(char *txdat,int len,char *rxdat){
	int i;
	for(i=0;i<len;i++)rxdat[i]=spi_tx(txdat[i]);
	return len;
}

