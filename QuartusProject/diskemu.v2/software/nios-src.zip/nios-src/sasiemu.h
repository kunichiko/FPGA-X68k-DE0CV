/*
 * sasiemu.h
 */

#ifndef SASIEMU_H_
#define SASIEMU_H_

#include "system.h"
#include "ff.h"
#include "altera_avalon_pio_regs.h"

#define HD_NONE	0
#define HD_FILE 1

void ini_sasi(FATFS *fs,int num,int size,int *flag,char **name,char *vaddr,int locate);
void intsasisel(void);

#endif /* SASIEMU_H_ */
