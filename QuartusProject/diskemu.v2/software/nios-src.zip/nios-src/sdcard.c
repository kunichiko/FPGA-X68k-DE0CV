/*
 * sdcard.c
 */

#include <stdio.h>
#include <unistd.h>
#include "sdcard.h"

#define inittout	10000

DSTATUS sd_status=STA_NOINIT | STA_NODISK;

DSTATUS SD_disk_status(void){
	return sd_status;
}

int isblockaddr;

void setcmd(char *buf,int cmd,int arg){
	buf[0]=0x40 | (cmd & 0x3f);
	buf[4]=arg & 0x0ff;
	arg>>=8;
	buf[3]=arg & 0x0ff;
	arg>>=8;
	buf[2]=arg & 0x0ff;
	arg>>=8;
	buf[1]=arg & 0x0ff;
	buf[5]=0x01;
}

int checksdhc(void){
	char txdat[6],rxdat[6];
	setcmd(txdat,8,0x1aa);
	txdat[5]=0x87;
	spi_txstr(txdat,6,rxdat);
	return sd_waitcresp();
}

int sd_waitcresp(void){
	int i;
	char datum;
	for(i=0;i<1000;i++){
		datum=spi_tx(0xff);
		if(!(datum&0x80))return (int)(datum & 0xff);
	}
	return -1;
}

int sd_waitdresp(void){
	int i;
	char datum;
	for(i=0;i<1000;i++){
		datum=spi_tx(0xff);
		switch(datum){
		case 0xfe:
		case 0xfc:
		case 0xfd:
			return datum;
		default:
			break;
		}
		if((datum&0xe0)==0x00)return datum;
	}
	return 0;
}

DSTATUS SD_disk_initialize(void){
	char txdat[6],rxdat[6],rxchar;
	int i,j;
	spi_speed(0);
	isblockaddr=0;
	sd_status=STA_NOINIT | STA_NODISK;
	spi_init();
	spi_blank(10);
	setcmd(txdat,0,0);	//CMD0 with CS=L:Change to SPI mode
	txdat[5]=0x95;
	spi_txstr(txdat,6,rxdat);
	if(sd_waitcresp()<0){
		sd_status=STA_NOINIT | STA_NODISK;
		return sd_status;
	}
	spi_blank(1);
	if(checksdhc()==0x01){		//is SDHC
		for(i=0;i<4;i++)txdat[i]=0xff;
		spi_txstr(txdat,4,rxdat);
//		spi_tx(0xff);
		if((rxdat[2]&0x0f)!=0x01 || (rxdat[3]&0xff)!=0xaa){
			sd_status=STA_NOINIT | STA_NODISK;
			return sd_status;
		}
		spi_blank(1);
		for(i=0;i<inittout;i++){
			setcmd(txdat,55,0);		//ACMD41 :SDHC init
			spi_txstr(txdat,6,rxdat);
			sd_waitcresp();
			spi_blank(1);
			setcmd(txdat,41,1UL<<30);
			spi_txstr(txdat,6,rxdat);
			if(sd_waitcresp()==0x00)break;
			spi_blank(1);
			usleep(100);
		}
		spi_blank(1);
		if(i==inittout){
			sd_status=STA_NOINIT | STA_NODISK;
			return sd_status;
		}
	}else{						//is SDSC or MMC
		setcmd(txdat,1,0);	//CMD1 :INIT
		for(i=0;i<inittout;i++){
			spi_txstr(txdat,6,rxdat);
			if(sd_waitcresp()==0x00)break;
			spi_blank(1);
			usleep(100);
		}
		if(i==inittout){
			sd_status=STA_NOINIT | STA_NODISK;
			return sd_status;
		}
		spi_blank(1);
	}
	spi_speed(1);
	spi_blank(1);
	setcmd(txdat,16,512);	//cmd16:set block size(512)
	spi_txstr(txdat,6,rxdat);
	sd_waitcresp();
	spi_blank(1);
	setcmd(txdat,58,0);	//cmd58 : get OCR
	spi_txstr(txdat,6,rxdat);
	sd_waitcresp();
	for(i=0;i<4;i++)txdat[i]=0xff;
	spi_txstr(txdat,4,rxdat);
//	spi_tx(0xff);
	spi_blank(1);
	isblockaddr=(rxdat[0]&0x40)?1:0;	//CCS
	sd_status=0;
	return sd_status;
}

DRESULT SD_disk_read(BYTE *buf,DWORD sector,UINT count){
	int i,j;
	int addr;
	char txdat[6],rxdat[6],datum;

	for(i=0;i<count;i++){
		addr=isblockaddr? sector : sector<<9;
		setcmd(txdat,17,addr);
		spi_txstr(txdat,6,rxdat);
		for(j=0;j<1000;j++){
			datum=spi_tx(0xff);
			if((datum&0xff)==0xfe)break;
			if((datum&0xff)==0x01)return RES_PARERR;
		}
		if(j==1000){
			sd_status=STA_NOINIT | STA_NODISK;
			return RES_NOTRDY;
		}
		for(j=0;j<512;j++){
			*buf=spi_tx(0xff);
			buf++;
		}
		spi_tx(0xff);
		spi_tx(0xff);
		spi_tx(0xff);
		spi_blank(1);
		sector++;
	}
	return RES_OK;
}

DRESULT SD_disk_write(const BYTE *buf,DWORD sector,UINT count){
	int i,j;
	int addr;
	char txdat[6],rxdat[6],datum;

	for(i=0;i<count;i++){
		addr=isblockaddr? sector : sector<<9;
		setcmd(txdat,24,addr);
		spi_txstr(txdat,6,rxdat);
		for(j=0;j<10000;j++){
			datum=spi_tx(0xff);
			if(datum==0x00)break;
		}
		if(j==1000){
			sd_status=STA_NOINIT | STA_NODISK;
			return RES_NOTRDY;
		}
		spi_tx(0xfe);
		for(j=0;j<512;j++){
			spi_tx(*buf);
			buf++;
		}
		spi_tx(0x00);
		spi_tx(0x00);
		datum=spi_tx(0xff);
		if((datum&0x1f)!=0x05){
			spi_blank(1);
			return RES_ERROR;
		}
		for(j=0;j<1000;j++){
			usleep(100);
			datum=spi_tx(0xff);
			if((datum&0xff)==0xff)break;
		}
		if(j==1000){
			sd_status=STA_NOINIT | STA_NODISK;
			return RES_NOTRDY;
		}
		spi_blank(1);
		sector++;
	}
	return RES_OK;
}

DRESULT SD_disk_ioctl(BYTE cmd,void *buf){
	return RES_OK;
}

DWORD get_fattime(void){
	return 0x12345678;
}
