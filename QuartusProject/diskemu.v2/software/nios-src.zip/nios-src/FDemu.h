/*
 * FDemu.h
 */

#ifndef FDEMU_H_
#define FDEMU_H_

#include "system.h"
#include "ff.h"
#include "altera_avalon_pio_regs.h"
#include "crccalc.h"

#define FD_NONE 0
#define FD_DRV0 1
#define FD_DRV1 2
#define FD_FILE 3
#define FD_EJECT 4

#define DM_2D	0x00
#define DM_2DD	0x01
#define DM_2HD	0x02
#define DM_IBM	0x03

#endif /* FDEMU_H_ */
