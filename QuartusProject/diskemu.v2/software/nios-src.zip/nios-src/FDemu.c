/*
 * FDemu.c
 */
#include<stdio.h>
#include "FDemu.h"
#include "sys/alt_irq.h"

FATFS *fs;
static char **filename;
static int *diskflag;
static int drives;
static int indoffset;
static char *vattr;
short *fdram;
static int wroteflag;

static int active[4];

static char **trackmode;
static char *protect;
static char *disktype;
static int bufaddrh;
static int wrotesub;

int str2int(char *str,int len){
	int dat=0,i;
	for(i=0;i<len;i++){
		dat<<=8;
		dat|=(str[len-i-1])&0x0ff;
	}
	return dat;
}

void writeram(void){
	int flag;
	if(!wroteflag)return;
	wroteflag=0;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMADDR_BASE,bufaddrh);
	usleep(1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMWR_BASE,1);
	usleep(1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMWR_BASE,0);
	while(flag=IORD_ALTERA_AVALON_PIO_DATA(PIO_FDRAMBUSY_BASE));
}

void ramwr(int unit,int track,int side,int pos,char dat,int mc,int mfm,int wrote){
	short tmp;
	int addrh;
	addrh=unit&0x03;
	addrh<<=7;
	addrh|=track&0x7f;
	addrh<<=1;
	addrh|=side?1:0;
	addrh<<=6;
	addrh|=((pos&0x3f00)>>8);
	if(bufaddrh!=addrh){
		writeram();
		bufaddrh=addrh;
	}
	tmp=dat & 0x00ff;
	tmp|=mc?0x100:0x000;
	tmp|=mfm?0x200:0x000;
	tmp|=wrote?0x400:0x000;
	fdram[pos&0x0ff]=tmp;
	crccalc(dat);
	wroteflag=1;
}

void readram(int addr){
	int flag;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMADDR_BASE,addr);
	usleep(1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMRD_BASE,1);
	usleep(1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDRAMRD_BASE,0);
	while(flag=IORD_ALTERA_AVALON_PIO_DATA(PIO_FDRAMBUSY_BASE));
}

char ramrd(int unit,int track,int side,int pos,int *mc,int *mfm,int *wrote){
	short tmp;
	int addrh;
	addrh=unit&0x03;
	addrh<<=7;
	addrh|=track&0x7f;
	addrh<<=1;
	addrh|=side?1:0;
	addrh<<=6;
	addrh|=((pos&0x3f00)>>8);
	if(bufaddrh!=addrh){
		readram(addrh);
		bufaddrh=addrh;
	}
	tmp=fdram[pos&0x0ff];
	*mc=tmp&0x100?1:0;
	*mfm=tmp&0x200?1:0;
	*wrote=tmp&0x400?1:0;
	crccalc(tmp&0x0ff);
	return tmp&0x0ff;
}

int loadtrack(int drive,int mode,int tracklen,int *tracktbl,int track,int side,int trackmode){
	FIL file;
	char type,secthead[0x10],buf[16];
	int i,j,k,len,sectors,sectsize,pos,mfm,gaplen,crc,htrack;
	int flag=1;
	volatile alt_irq_context ic;
	if(diskflag[drive]!=FD_FILE)return 0;
	htrack=trackmode?track:track*2;
//	printf("drive %d:track %d read\n",drive,trackside);
	ic=alt_irq_disable_all();
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,1);
	if(f_open(&file,filename[drive],FA_READ)!=FR_OK){
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
		alt_irq_enable_all(ic);
		return -1;
	}
	f_lseek(&file,tracktbl[track*2+side]);
	f_read(&file,secthead,0x10,&len);
	mfm=secthead[0x06]?0:1;
	sectors=(secthead[0x05]<<8)&0xff00;
	sectors|=(secthead[0x04]&0x00ff);
	tracklen*=mfm?2:1;
	pos=0;
	gaplen=mfm?80:40;
	if(tracktbl[track*2+side]==0){
		for(i=0;i<tracklen;i++)ramwr(drive,htrack,side,i,0,0,1,0);
		f_close(&file);
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
		alt_irq_enable_all(ic);
		return 0;
	}
	for(i=0;i<gaplen;i++)ramwr(drive,htrack,side,pos++,mfm?0x4e:0xff,0,mfm,0);	//gap0
	f_lseek(&file,tracktbl[track*2+side]);
	for(i=0;i<sectors;i++){
		f_read(&file,secthead,0x10,&len);
		mfm=secthead[0x06]?0:1;
		gaplen=mfm?10:5;
		for(j=0;j<gaplen;j++)ramwr(drive,htrack,side,pos++,mfm?0x4e:0xff,0,mfm,0);	//gap1
		gaplen=mfm?12:6;
		for(j=0;j<gaplen;j++)ramwr(drive,htrack,side,pos++,0x00,0,mfm,0);	//synci
		crcclr(-1);
		if(mfm){
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,0xfe,0,1,0);
		}else ramwr(drive,htrack,side,pos++,0xfe,1,0,0);
		ramwr(drive,htrack,side,pos++,secthead[0],0,mfm,0);	//C
		ramwr(drive,htrack,side,pos++,secthead[1],0,mfm,0);	//H
		ramwr(drive,htrack,side,pos++,secthead[2],0,mfm,0);	//R
		ramwr(drive,htrack,side,pos++,secthead[3],0,mfm,0);	//N
		crc=crcget();
		ramwr(drive,htrack,side,pos++,(crc>>8)&0xff,0,mfm,0);	//crc(H)
		ramwr(drive,htrack,side,pos++,((crc^((secthead[8]==0xa0)?0xff:0x00))&0xff),0,mfm,0);		//crc(L)
		gaplen=mfm?22:11;
		for(j=0;j<gaplen;j++)ramwr(drive,htrack,side,pos++,mfm?0x4e:0xff,0,mfm,0);	//gap2
		gaplen=mfm?12:6;
		for(j=0;j<gaplen;j++)ramwr(drive,htrack,side,pos++,0x00,0,mfm,0);	//syncd
		crcclr(-1);
		if(mfm){
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,0xa1,1,1,0);
			ramwr(drive,htrack,side,pos++,secthead[7]?0xf8:0xfb,0,1,0);
		}else ramwr(drive,htrack,side,pos++,secthead[7]?0xf8:0xfb,1,0,0);
		sectsize=(secthead[0x0f]<<8)&0xff00;
		sectsize|=(secthead[0x0e]&0x00ff);
		for(j=0;j<sectsize;j+=16){
			f_read(&file,buf,16,&len);
			for(k=0;k<16;k++)ramwr(drive,htrack,side,pos++,buf[k],0,mfm,0);
		}
		crc=crcget();
		ramwr(drive,htrack,side,pos++,(crc>>8)&0xff,0,mfm,0);	//crc(H)
		ramwr(drive,htrack,side,pos++,((crc^((secthead[8]==0xb0)?0xff:0x00))&0xff),0,mfm,0);		//crc(L)
	}
	if(flag){
		for(i=pos;i<tracklen;i++)ramwr(drive,htrack,side,pos++,mfm?0x4e:0xff,0,mfm,0);
	}
	f_close(&file);
	writeram();
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
	alt_irq_enable_all(ic);
	return pos;
}

//IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE,0x00);

int savetrack(int drive,int mode,int tracklen,int *tracktbl,int track,int side,int trackmode){
	int i,j,k,len,sectors,sectsize,pos,mfm,htrack,wrote,wrsum;
	int curoff,stateoff;
	int idcrcerr;
	char secthead[0x10],type,buf[16];
	unsigned char rddat[4];
	int rdmc[4];
	int flag;
	FIL file;
	FRESULT res;
	htrack=trackmode?track:track*2;
//	if(!IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE))return 0;	//not written
//	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE,0x00);
//	printf("drive %d:track %d write\n",drive,trackside);
	if(diskflag[drive]!=FD_FILE || protect[drive])return 0;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,1);
	if(tracktbl[track*2+side]==0){
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
		return 0;
	}
	ramrd(drive,htrack,side,0,&rdmc[3],&mfm,&wrote);
	tracklen*=mfm?2:1;
	sectors=0;					//sector counter
	for(j=0;j<3;j++){
		rddat[j]=0x00;
		rdmc[j]=0;
	}
	wrsum=0;
	for(i=0;i<tracklen;i++){
		for(j=0;j<3;j++){
			rddat[j]=rddat[j+1];
			rdmc[j]=rdmc[j+1];
		}
		rddat[3]=ramrd(drive,htrack,side,i,&rdmc[3],&mfm,&wrote);
		if(mfm)sectors+=(rddat[0]==0xa1 && rdmc[0] && rddat[1]==0xa1 && rdmc[1] && rddat[2]==0xa1 && rdmc[2] && rddat[3]==0xfe && !rdmc[3])?1:0;
		else sectors+=(rddat[0]==0xfe && rdmc[0])?1:0;
		wrsum|=wrote;
	}
	if(!wrsum){		//track not wrote
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
		return 0;
	}
	if(f_open(&file,filename[drive],FA_READ|FA_WRITE|FA_OPEN_ALWAYS)!=FR_OK)return -1;
	pos=0;
	res=f_lseek(&file,tracktbl[track*2+side]);
	curoff=tracktbl[track*2+side];
	for(j=0;j<3;j++){
		rddat[j]=0x00;
		rdmc[j]=0;
	}
	for(i=0;i<sectors;i++){
		flag=1;
		idcrcerr=0;		//IDM detect
		do{
			for(j=0;j<3;j++){
				rddat[j]=rddat[j+1];
				rdmc[j]=rdmc[j+1];
			}
			rddat[3]=ramrd(drive,htrack,side,pos++,&rdmc[3],&mfm,&wrote);
			if(mfm){
				if(rddat[0]==0xa1 && rdmc[0] && rddat[1]==0xa1 && rdmc[1] && rddat[2]==0xa1 && rdmc[2] && rddat[3]==0xfe && !rdmc[3])flag=0;
			}else{
				if(rddat[3]==0xfe && rdmc[3])flag=0;
			}
		}while(flag);
		crcclr(-1);
		if(mfm)for(j=0;j<3;j++)crccalc(rddat[j]);
		crccalc(rddat[3]);
		for(j=0;j<4;j++){
			rddat[j]=ramrd(drive,htrack,side,pos++,&rdmc[j],&mfm,&wrote);
			secthead[j]=rddat[j];
		}

		switch(rddat[3]){
		case 0x00:
			sectsize=128;
			break;
		case 0x01:
			sectsize=256;
			break;
		case 0x02:
			sectsize=512;
			break;
		case 0x03:
			sectsize=1024;
			break;
		case 0x04:
			sectsize=2048;
			break;
		case 0x05:
			sectsize=4096;
			break;
		case 0x06:
			sectsize=8192;
			break;
		default:
			sectsize=16384;
			break;
		}
		ramrd(drive,htrack,side,pos++,&rdmc[3],&mfm,&wrote);
		ramrd(drive,htrack,side,pos++,&rdmc[3],&mfm,&wrote);
		idcrcerr=crcget();
		secthead[4]=(sectors&0xff);
		secthead[5]=(sectors>>8)&0xff;
		secthead[6]=mfm?0x00:0x40;
		flag=1;					//DAM detect
		for(j=0;j<3;j++){
			rddat[j]=0x00;
			rdmc[j]=0;
		}
		do{
			for(j=0;j<3;j++){
				rddat[j]=rddat[j+1];
				rdmc[j]=rdmc[j+1];
			}
			rddat[3]=ramrd(drive,htrack,side,pos++,&rdmc[3],&mfm,&wrote);
			if(mfm){
				if(rddat[0]==0xa1 && rdmc[0] && rddat[1]==0xa1 && rdmc[1] && rddat[2]==0xa1 && rdmc[2] && (rddat[3]==0xf8 || rddat[3]==0xfb) && !rdmc[3])flag=0;
			}else{
				if((rddat[3]==0xf8 || rddat[3]==0xfb) && rdmc[3])flag=0;
			}
		}while(flag);
		secthead[7]=(rddat[3]==0xfb)?0x00:0x10;
		secthead[8]=(rddat[3]==0xfb)?0x00:0x10;
		if(idcrcerr)secthead[8]=0xa0;
		for(j=0;j<5;j++)secthead[9+j]=0x00;
		secthead[0xe]=(sectsize&0xff);
		secthead[0xf]=(sectsize>>8)&0xff;
		res=f_write(&file,secthead,0x10,&len);
		crcclr(-1);
		if(mfm){
			for(j=0;j<3;j++)crccalc(rddat[j]);
		}
		crccalc(rddat[3]);
		stateoff=curoff+0x08;
		curoff+=0x10;
		for(j=0;j<sectsize;j+=16){
			for(k=0;k<16;k++)buf[k]=ramrd(drive,htrack,side,pos++,&rdmc[3],&mfm,&wrote);
			res=f_write(&file,buf,16,&len);
			curoff+=16;
		}
		ramrd(drive,htrack,side,pos++,&rdmc,&mfm,&wrote);	//crc(H)
		ramrd(drive,htrack,side,pos++,&rdmc,&mfm,&wrote);	//crc(L)
		if(crcget()){
			res=f_lseek(&file,stateoff);
			f_putc(0xb0,&file);
			res=f_lseek(&file,curoff);
		}
	}
	res=f_close(&file);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
	return sectors;
}

void fde_setconfig(void){
	int i,bit=1;
	int fddsel0=0,fddsel1=0,fdesel=0,fdeindisk=0;
	for(i=0;i<drives;i++){
		switch(diskflag[i]){
		case FD_DRV0:
			fddsel0|=bit;
			break;
		case FD_DRV1:
			fddsel1|=bit;
			break;
		case FD_FILE:
			fdeindisk|=bit;
		case FD_EJECT:
			fdesel|=bit;
			break;
		default:
			break;
		}
		bit<<=1;
	}
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDSEL0_BASE,fddsel0);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDSEL1_BASE,fddsel1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEMUEN_BASE,fdesel);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDINDISK_BASE,fdeindisk);
}

int fde_loadinfo_d88(int drive,int *mode,int *tracklen,int *tracktbl,int *tracks){
	FIL file;
	int i,len,imgsize,lastoff,curoff,track,tmp;
	char buf[0x2b0];
	volatile alt_irq_context ic;
	if(diskflag[drive]==FD_FILE){
		ic=alt_irq_disable_all();
		if(f_open(&file,filename[drive],FA_READ)!=FR_OK){
			alt_irq_enable_all(ic);
			return -1;
		}
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,1);
		f_read(&file,buf,0x2b0,&len);
		protect[drive]=buf[0x1a];
		disktype[drive]=buf[0x1b];
		imgsize=str2int(&buf[0x1c],4);
		lastoff=imgsize;
		f_lseek(&file,0x20);
		f_read(&file,tracktbl,164*sizeof(int),&len);
		f_close(&file);
		alt_irq_enable_all(ic);
		switch(disktype[drive]){
		case 0x00:
			*tracks=41;
			*mode=DM_2D;
			*tracklen=3125;
			break;
		case 0x10:
			*tracks=82;
			*mode=DM_2DD;
			*tracklen=3125;
			break;
		case 0x20:
			*tracks=82;
			*mode=DM_2HD;
			*tracklen=6250;
			break;
		default:
			*tracks=0;
			*mode=-1;
			*tracklen=0;
			break;
		}
		tmp=0;
		for(i=0;i<drives;i++)tmp|=protect[i]?1<<i:0;
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDWPROT_BASE,tmp);
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODEOUT_BASE,*mode<<drive*2);
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODESET_BASE,1<<drive);
		usleep(1);
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODESET_BASE,0x00);
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);
	}
	return 0;
}

int fde_loaddisk(int drive){
	int flag=0,mode,tracklen,tracktbl[164],tracks,track,side,trackmode,i;
	extern scr_size_C;
	flag|=fde_loadinfo_d88(drive,&mode,&tracklen,tracktbl,&tracks)?1:0;
	vattr[scr_size_C*(drive+indoffset)]=0x20;
	switch(mode){
	case DM_2D:
		trackmode=0;
		break;
	case DM_2DD:
	case DM_2HD:
		trackmode=1;
		break;
	default:
		trackmode=0;
		break;
	}
	for(track=0;track<tracks;track++){
		for(side=0;side<2;side++){
//			printf("Dr:%d Tr:%d Si:%d mode:%d\n",drive,track,side,trackmode);
			printgauge(track*2+side,164);
			loadtrack(drive,mode,tracklen,tracktbl,track,side,trackmode);
		}
	}
	cleargauge();
	vattr[scr_size_C*(drive+indoffset)]=0x07;
	return flag;
}

int fde_loaddisks(void){
	int drive,flag;
	flag=0;
	for(drive=0;drive<drives;drive++)if(diskflag[drive]==FD_FILE)flag|=fde_loaddisk(drive);
	return flag;
}

int fde_savedisk(int drive){
	int i,tracks,track,side,trackmode,flag,mask,flmask,mode,tracklen,tracktbl[164];
	extern scr_size_C;
	mask=1<<drive;
	flmask=~mask;
	flag=IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE);
	flag|=wrotesub;
	flmask&=flag;
	wrotesub=flmask;
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE,0);
	if(!(flag&mask))return 0;
	vattr[scr_size_C*(drive+indoffset)]=0x80;
	flag=fde_loadinfo_d88(drive,&mode,&tracklen,tracktbl,&tracks);
	switch(mode){
	case DM_2D:
		trackmode=0;
		break;
	case DM_2DD:
	case DM_2HD:
		trackmode=1;
		break;
	default:
		trackmode=0;
		break;
	}
	for(track=0;track<tracks;track++){
		for(side=0;side<2;side++){
			printgauge(track*2+side,164);
			savetrack(drive,mode,tracklen,tracktbl,track,side,trackmode);
		}
	}
	cleargauge();
	vattr[scr_size_C*(drive+indoffset)]=0x07;
	return 0;
}

void int_eject(void){
	int drive,flag;
	flag=IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDEJECT_BASE);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDEJECT_BASE,0x00);
	for(drive=0;drive<drives;drive++){
		if(flag&0x01 && diskflag[drive]==FD_FILE){
			fde_savedisk(drive);
			diskflag[drive]=FD_EJECT;
		}
		flag>>=1;
	}
	fde_setconfig();
}

void int_motoroff(void){
	int drive,flag;
	flag=IORD_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDMOTOR_BASE);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDMOTOR_BASE,0x00);
	for(drive=0;drive<drives;drive++){
		if(flag&0x01 && diskflag[drive]==FD_FILE){
			fde_savedisk(drive);
		}
		flag>>=1;
	}
}

void ini_fdemu(int num,int *flag,char **name,char *addr,int locate){
	int i;
	drives=num;
	diskflag=flag;
	filename=name;
	indoffset=locate;
	fdram=FDRAM_BASE;
	vattr=addr;
	crcinit(16,-1,0x1021);
	bufaddrh=-1;
	wroteflag=0;
	wrotesub=0;

	for(i=0;i<num;i++)active[i]=0;
	trackmode=(char **)malloc(num*sizeof(char *));
	for(i=0;i<num;i++)trackmode[i]=(char *)malloc(164*sizeof(char));
	protect=(char *)malloc(num*sizeof(char));
	disktype=(char *)malloc(num*sizeof(char));
	for(i=0;i<num;i++){
		protect[i]=0x00;
		disktype[i]=0x00;
	}

	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODEOUT_BASE,0x00);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODESET_BASE,0x0f);
	usleep(1);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDMODESET_BASE,0x00);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDSEL0_BASE,0x01);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDSEL1_BASE,0x02);
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_FDEBUSY_BASE,0);

	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_FDEJECT_BASE,0x0f);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDEJECT_BASE,0x00);
	alt_irq_register(PIO_FDEJECT_IRQ,0,int_eject);
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_FDMOTOR_BASE,0x0f);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDMOTOR_BASE,0x00);
	alt_irq_register(PIO_FDMOTOR_IRQ,0,int_motoroff);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_FDWROTE_BASE,0x00);
}
