/*
 * sramemu.c
 */

#include "sramemu.h"


FATFS *Fat;
static char *filename;
static int datlen;
static char *ram;

int loadsram(void){
	FIL file;
	int status,len;

	if((status=f_open(&file,filename,FA_READ))!=FR_OK)return -1;
	if((status=f_read(&file,ram,datlen,&len))!=FR_OK){
		f_close(&file);
		return -1;
	}
	f_close(&file);
	return len;
}

int savesram(void){
	FIL file;
	int status,len;

	if((status=f_open(&file,filename,FA_WRITE | FA_OPEN_ALWAYS))!=FR_OK)return -1;
	status=f_write(&file,ram,datlen,&len);
	f_close(&file);
	return len;
}

void int_nvsave(void){
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_NVSAVE_BASE, 0);
	savesram();
}

int ini_sram(FATFS *fs,int len,char *name,int flag){
	int status;
	filename=name;
	Fat=fs;
	datlen=len;
	ram=NVSRAM_BASE;
	IOWR_ALTERA_AVALON_PIO_IRQ_MASK(PIO_NVSAVE_BASE,0x01);
	IOWR_ALTERA_AVALON_PIO_EDGE_CAP(PIO_NVSAVE_BASE,0x00);
	alt_irq_register(PIO_NVSAVE_IRQ,0,int_nvsave);
	if(flag){
		IOWR_ALTERA_AVALON_PIO_DATA(PIO_INITDONE_BASE,0);
		status=loadsram();
	}
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_INITDONE_BASE,1);
	return 0;
}

