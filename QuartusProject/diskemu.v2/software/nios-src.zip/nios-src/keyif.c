/*
 * keyif.c
 */

#include "keyif.h"
#include "altera_avalon_fifo_regs.h"
#include "altera_avalon_fifo_util.h"
#include "altera_avalon_fifo.h"

int shifted=0,ctrled=0;

const char tbln[128]={
		  // 00   01   02   03   04   05   06   07   08   09   0a   0b   0c   0d   0e   0f
/*00*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\t','\0','\0',
/*10*/		'\0','\0','\0','\0','\0','q' ,'1' ,'\0','\0','\0','z' ,'s' ,'a' ,'w' ,'2' ,'\0',
/*20*/		'\0','c' ,'x' ,'d' ,'e' ,'4' ,'3' ,'\0','\0',' ' ,'v' ,'f' ,'t' ,'r' ,'5' ,'\0',
/*30*/		'\0','n' ,'b' ,'h' ,'g' ,'y' ,'6' ,'\0','\0','\0','m' ,'j' ,'u' ,'7' ,'8' ,'\0',
/*40*/		'\0',',' ,'k' ,'i' ,'o' ,'0' ,'9' ,'\0','\0','.' ,'/' ,'l' ,';' ,'p' ,'-' ,'\0',
/*50*/		'\0','\\',':' ,'\0','@' ,'^' ,'\0','\0','\0','\0','\n','[' ,'\0',']' ,'\0','\0',
/*60*/		'\0',' ', ' ', '\0','\0','\0',0x08,'\0','\0','1' ,'\\','4' ,'7' ,'\0','\0','\0',
/*70*/		'0' ,'.' ,'2' ,'5' ,'6' ,'8' ,0x1b,'\0','\0','+' ,'3' ,'-' ,'*' ,'9' ,'\0','\0',
};

const char tbls[128]={
		  // 00   01   02   03   04   05   06   07   08   09   0a   0b   0c   0d   0e   0f
/*00*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\t','\0','\0',
/*10*/		'\0','\0','\0','\0','\0','Q' ,'!' ,'\0','\0','\0','Z' ,'S' ,'A' ,'W' ,'"' ,'\0',
/*20*/		'\0','C' ,'X' ,'D' ,'E' ,'$' ,'#' ,'\0','\0','\0','V' ,'F' ,'T' ,'R' ,'%' ,'\0',
/*30*/		'\0','N' ,'B' ,'H' ,'G' ,'Y' ,'&' ,'\0','\0','\0','M' ,'J' ,'U' ,'\'','(' ,'\0',
/*40*/		'\0','<' ,'K' ,'I' ,'O' ,'\0',')' ,'\0','\0','>' ,'?' ,'L' ,'+' ,'P' ,'=' ,'\0',
/*50*/		'\0','_' ,'*' ,'\0','`' ,'~' ,'\0','\0','\0','\0','\n','{' ,'\0','}' ,'\0','\0',
/*60*/		'\0',' ', ' ', '\0','\0','\0',0x08,'\0','\0','1' ,'|' ,'4' ,'7' ,'\0','\0','\0',
/*70*/		'0' ,'.' ,'2' ,'5' ,'6' ,'8' ,0x1b,'\0','\0','+' ,'3' ,'-' ,'*' ,'9' ,'\0','\0',
};

const char tble0[128]={
		  // 00   01   02   03   04   05   06   07   08   09   0a   0b   0c   0d   0e   0f
/*00*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
/*10*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
/*20*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
/*30*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
/*40*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','/' ,'\0','\0','\0','\0','\0',
/*50*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\n','\0','\0','\0','\0','\0',
/*60*/		'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',0x1d,'\0','\0','\0','\0',
/*70*/		'\0','\0',0x1f,'\0',0x1c,0x1e,'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',
};

void ini_kb(void){
	altera_avalon_fifo_init(KBFIFO_OUT_CSR_BASE,0,0,15);
	shifted=0;
//	alt_irq_register(KBRX_IRQ,0,rxkey);
}

void rxkey(void){
	if(!altera_avalon_fifo_read_status(KBFIFO_OUT_CSR_BASE,ALTERA_AVALON_FIFO_STATUS_E_MSK))
		altera_avalon_fifo_read_fifo(KBFIFO_OUT_BASE,KBFIFO_OUT_CSR_BASE);
}

char keyin(void){
	int scode,f0flag,e0flag;
	char key;
	do{
		e0flag=0;f0flag=0;
		while(altera_avalon_fifo_read_status(KBFIFO_OUT_CSR_BASE,ALTERA_AVALON_FIFO_STATUS_E_MSK));
		scode=altera_avalon_fifo_read_fifo(KBFIFO_OUT_BASE,KBFIFO_OUT_CSR_BASE);
		if(scode==0xe0){
			e0flag=1;
			while(altera_avalon_fifo_read_status(KBFIFO_OUT_CSR_BASE,ALTERA_AVALON_FIFO_STATUS_E_MSK));
			scode=altera_avalon_fifo_read_fifo(KBFIFO_OUT_BASE,KBFIFO_OUT_CSR_BASE);
		}
		if(scode==0xf0){
			f0flag=1;
			while(altera_avalon_fifo_read_status(KBFIFO_OUT_CSR_BASE,ALTERA_AVALON_FIFO_STATUS_E_MSK));
			scode=altera_avalon_fifo_read_fifo(KBFIFO_OUT_BASE,KBFIFO_OUT_CSR_BASE);
		}
		if(scode==0x12 || scode==0x59){
			shifted=!f0flag;
		}
		if(scode==0x14){
			ctrled=!f0flag;
		}
	}while(scode==0x12 || scode==0x59 || f0flag);
	if(e0flag)key=tble0[scode];
	else key=shifted?tbls[scode]:tbln[scode];
	return key;
}

