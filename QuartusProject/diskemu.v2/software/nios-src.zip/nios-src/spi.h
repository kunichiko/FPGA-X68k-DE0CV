/*
 * spi.h
 */

#ifndef SPI_H_
#define SPI_H_

#include "alt_types.h"
#include "system.h"
#include "altera_avalon_spi_regs.h"
#include "altera_avalon_pio_regs.h"

void spi_init(void);
void spi_speed(int);
void spi_waitemp(void);
void spi_blank(int);
char spi_tx(char);
int spi_txstr(char *,int,char *);

#endif /* SPI_H_ */
