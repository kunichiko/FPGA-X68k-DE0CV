/*
 * sramemu.h
 */

#ifndef SRAMEMU_H_
#define SRAMEMU_H_

#include "system.h"
#include "ff.h"
#include "altera_avalon_pio_regs.h"

int ini_sram(FATFS *fs,int len,char *name,int flag);

#endif /* SRAMEMU_H_ */
