#include <stdio.h>
#include "crccalc.h"

int main(void){
	int i;
	crcinit(16,0,0x1021);
	crcclr(-1);
	crccalc(0xa1);
	crccalc(0xa1);
	crccalc(0xa1);
	crccalc(0xfe);
	crccalc(0x06);
	crccalc(0x01);
	crccalc(0x01);
	crccalc(0x03);
	printf("%04x\n",crcget()&0x0ffff);
	crccalc(0xca);
	crccalc(0xe7);
	printf("%04x\n",crcget()&0x0ffff);
	crcclr(-1);
	crccalc(0xa1);
	crccalc(0xa1);
	crccalc(0xa1);
	crccalc(0xfe);
	crccalc(0x02);
	crccalc(0x00);
	crccalc(0x03);
	crccalc(0x02);
	crccalc(0x41);
	crccalc(0x65);
	printf("%04x\n",crcget()&0x0ffff);
	
}
