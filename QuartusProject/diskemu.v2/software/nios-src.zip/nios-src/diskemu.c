#include <stdio.h>
#include <stdlib.h>
#include "ff.h"
#include "system.h"
#include "txtscreen.h"
#include "keyif.h"
#include "FDemu.h"
#include "sasiemu.h"
#include "sramemu.h"
#include "altera_avalon_pio_regs.h"
#include "sys/alt_irq.h"

static char ver[]="ver. 3.13";

char **FDfname;
char **HDfname;
char SRAMfname[_MAX_LFN+1];
int FDflag[4];
int HDflag[16];
static int powerflag=0;
static int *isdir;

enum kind_t {knd_FDD,knd_HDD,knd_SRAM};


FATFS Fat;
const char conffilenametbl[3][20]={
		".config.p88",
		".config.p98",
		".config.x68"};
const int modelfunc[3][4]={	//num of FDD,num of HDD,HDD sectorsize,sram words
		{2,0,0,0},	//PC-8801 FDDx2,HDDx0,SRAMx0
		{4,2,256,16},	//PC-9801 FDDx4,HDDx2,SRAMx16
		{4,16,256,16384}	//X68000 FDDx4,HDDx16 SRAMx16k
};
const int txtsize[3][2]={
		{80,25},	//PC-8801 80x25
		{80,25},	//PC-9801 80x25
		{100,37}	//X68000 100x37
};
int *func;
char *conffilename;

int main()
{
	FRESULT res;
//	FILINFO fno;
//	DIR dir;
//	char path[_MAX_LFN+1]="0:";
//	char *fn;
	char *tmp;
//	static char lfn[_MAX_LFN+1];
//	char str[_MAX_LFN+5];
	int model,i;
	enum kind_t kind[21];
	int unit[21];
	char key;

	int line=0,maxline;
	extern int scr_size_L;
	IOWR_ALTERA_AVALON_PIO_DATA(PIO_INITDONE_BASE,0);
	model=IORD_ALTERA_AVALON_PIO_DATA(MODEL_BASE);
	func=modelfunc[model];

	FDfname=(char **)malloc(func[0]*sizeof(char *));
	for(i=0;i<func[0];i++)FDfname[i]=(char *)malloc((_MAX_LFN+1)*sizeof(char));
	HDfname=(char **)malloc(func[1]*sizeof(char *));
	for(i=0;i<func[1];i++)HDfname[i]=(char *)malloc((_MAX_LFN+1)*sizeof(char));

	conffilename=conffilenametbl[model];
	ini_kb();
	ini_sasi(&Fat,func[1],func[2],HDflag,HDfname,s_getvattr(0,0),3+func[0]);
	s_init(txtsize[model][1],txtsize[model][0]);
	s_cls();
	title();
	res=f_mount(&Fat,"",0);
	loadconf();
	ini_fdemu(func[0],FDflag,FDfname,s_getvattr(0,0),3);
	maxline=showlist(kind,unit);
	showconfline();
	fde_setconfig();
	fde_loaddisks();

	isdir=(int *)malloc(scr_size_L*sizeof(int));
	ini_sram(&Fat,func[3],SRAMfname,!powerflag);
	powerflag=1;
	line=0;
	setline(line,0x60);
	while(1){
		key=keyin();
		switch(key){
		case KEY_UP:
			setline(line,0x07);
			if(line>0)line--;
			setline(line,0x60);
			break;
		case KEY_DOWN:
			setline(line,0x07);
			if(line<maxline-1)line++;
			else sel_saverestore();
			setline(line,0x60);
			break;
		case '\n':
		case ' ':
			setline(line,0x40);
			switch(kind[line]){
			case knd_FDD:
				selectFDD(unit[line]);
				break;
			case knd_HDD:
				selectHDD(unit[line]);
				break;
			case knd_SRAM:
				selectSRAM();
				break;
			default:
				break;
			}
			setline(line,0x60);
			break;
		default:
			break;
		}
	}
	return 0;
}

void title(void){
	char str[]="SD CARD DISK EMULATION UTILITY";
	int i;
	extern int scr_size_C;
	s_setattr(0,1,0);
	for(i=0;i<strlen(str)+2;i++)s_putc(' ');
	s_newline();
	s_putc(0x20);
	s_setattr(7,0,0);
	s_puts(str);
	s_setattr(0,1,0);
	s_putc(0x20);
	s_newline();
	for(i=0;i<strlen(str)+2;i++)s_putc(' ');
	s_locate(-1,(scr_size_C-strlen(ver)-1));
	s_setattr(7,0,0);
	s_puts(ver);
}

void erasenl(char *buf){
	int len;
	len=strlen(buf);
	if(buf[len-1]=='\n')buf[len-1]='\0';
}

void loadconf(void){
	int model,i;
	char str[_MAX_LFN+1];
	volatile alt_irq_context ic;
	FIL file;
	ic=alt_irq_disable_all();
	if(f_open(&file,conffilename,FA_READ)!=FR_OK){
		createconf(conffilename);
		f_open(&file,conffilename,FA_READ);
	}
	for(i=0;i<func[0];i++){
		f_gets(str,3,&file);
		FDflag[i]=str[0]-'0';
		f_gets(FDfname[i],_MAX_LFN+1,&file);
		erasenl(FDfname[i]);
	}
	for(i=0;i<func[1];i++){
		f_gets(str,3,&file);
		HDflag[i]=str[0]-'0';
		f_gets(HDfname[i],_MAX_LFN+1,&file);
		erasenl(HDfname[i]);
	}
	if(func[3]){
		f_gets(SRAMfname,_MAX_LFN+1,&file);
		erasenl(SRAMfname);
	}
	f_close(&file);
	alt_irq_enable_all(ic);
}

void createconf(char *filename){
	int i;
	for(i=0;i<func[0];i++){
		FDflag[i]=0;
		FDfname[i][0]='\0';
	}
	for(i=0;i<func[1];i++){
		HDflag[i]=0;
		HDfname[i][0]='\0';
	}
	SRAMfname[0]='\0';
	storeconfig(filename);
}

int storeconfig(char *filename){
	FIL file;
	char str[_MAX_LFN+4];
	int i,res;
	volatile alt_irq_context ic;
	ic=alt_irq_disable_all();
	if(f_open(&file,filename,FA_WRITE | FA_CREATE_ALWAYS)!=FR_OK){
		alt_irq_enable_all(ic);
		return 1;
	}
	for(i=0;i<func[0];i++){
		sprintf(str,"%d,%s\n",FDflag[i],FDfname[i]);
		res=f_puts(str,&file);
	}
	for(i=0;i<func[1];i++){
		sprintf(str,"%d,%s\n",HDflag[i],HDfname[i]);
		res=f_puts(str,&file);
	}
	if(func[3]){
		sprintf(str,"%s\n",SRAMfname);
		res=f_puts(str,&file);
	}
	res=f_close(&file);
	alt_irq_enable_all(ic);
	return 0;
}

void fillspace(char *buf,int len){
	int slen,i;
	slen=strlen(buf);
	for(i=slen;i<len;i++)buf[i]=' ';
	buf[len]='\0';
}
int showlist(enum kind_t *kind,int *unit){
	int lineno=0,i,j,model;
	char str[200];
	extern int scr_size_L,scr_size_C;
	s_locate(3,0);
	s_setattr(7,0,0);
	for(i=0;i<func[0];i++){
		s_clrline();
		sprintf(str," FDD %X:",i);
		s_puts(str);
		switch(FDflag[i]){
		case FD_NONE:
			sprintf(str,"NONE");
			break;
		case FD_DRV0:
			sprintf(str,"DRIVE 0");
			break;
		case FD_DRV1:
			sprintf(str,"DRIVE 1");
			break;
		case FD_EJECT:
			sprintf(str,"EJECTED");
			break;
		default:
			strncpy(str,FDfname[i],70);
			break;
		}
		fillspace(str,70);
		s_puts(str);
		s_newline();
		kind[lineno]=knd_FDD;
		unit[lineno]=i;
		lineno++;
	}
	for(i=0;i<func[1];i++){
		s_clrline();
		sprintf(str," HDD %X:",i);
		s_puts(str);
		switch(HDflag[i]){
		case FD_NONE:
			sprintf(str,"NONE");
			break;
		default:
			strncpy(str,HDfname[i],70);
			break;
		}
		fillspace(str,70);
		s_puts(str);
		s_newline();
		kind[lineno]=knd_HDD;
		unit[lineno]=i;
		lineno++;
	}
	if(func[3]){
		s_clrline();
		sprintf(str," SRAM :");
		s_puts(str);
		strncpy(str,SRAMfname,70);
		fillspace(str,70);
		s_puts(str);
		s_newline();
		kind[lineno]=knd_SRAM;
		unit[lineno]=0;
		lineno++;
	}
	str[0]='\0';
	fillspace(str,scr_size_C-1);
	for(i=lineno;i<scr_size_L-4;i++){
		s_puts(str);
		s_newline();
	}
	return lineno;
}

void showconfline(void){
	extern int scr_size_L;
	s_locate(scr_size_L-1,0);
	s_setdattr(0x07);
	s_puts(" SAVE   RESTORE REMOUNT                         ");
}
int selectitem(char *str,int width,int num,int updowncancel){
	int sel=0,i,j;
	int updown;
	char key;
	extern int scr_size_L;
	s_locate(scr_size_L-1,0);
	s_setattr(3,0,0);
	s_puts(str);
	do{
		for(i=0;i<num;i++)for(j=0;j<width;j++)s_chgdattr(scr_size_L-1,i*width+j,(sel==i)?0x60:0x03);
		key=keyin();
		if(key==KEY_RIGHT && sel<num-1)sel++;
		if(key==KEY_LEFT && sel>0)sel--;
		if((key==KEY_UP || key==KEY_DOWN) && updowncancel)updown=1;
		else updown=0;
	}while(key!='\n' && key!=' ' && key!=KEY_ESC && !updown);
	if(key==KEY_ESC || updown)return -1;
	return sel;
}

void printgauge(int level,int full,int attr){
	extern int scr_size_C,scr_size_L;
	int pos,i;
	char *vattr;
	vattr=s_getvattr(0,0);
	s_locate(scr_size_L-1,0);
	pos=scr_size_C*level/full;
	for(i=0;i<pos;i++){
		vattr[scr_size_C*(scr_size_L-1)+i]=attr;
	}
}
void cleargauge(void){
	extern int scr_size_C,scr_size_L;
	int i;
	char *vattr;
	vattr=s_getvattr(0,0);
	s_locate(scr_size_L-1,0);
	for(i=0;i<scr_size_C;i++){
		vattr[scr_size_C*(scr_size_L-1)+i]=0x07;
	}

}

void setline(int line,char attr){
	int i;
	extern int scr_size_C;
	for(i=1;i<scr_size_C-1;i++)s_chgdattr(line+3,i,attr);
}

void sel_saverestore(void){
	int sel,i;
	extern int scr_size_L;
	enum kind_t tmpkind[21];
	int tmpunit[21];
	sel=selectitem("",8,3,1);
	switch(sel){
	case 0:
		storeconfig(conffilename);
		break;
	case 1:
		loadconf();
		showlist(tmpkind,tmpunit);
		break;
	case 2:
		f_mount(0,"",0);
		f_mount(&Fat,"",0);
		break;
	default:
		break;
	}
	for(i=0;i<30;i++)s_chgdattr(scr_size_L-1,i,0x07);
}

void selectFDD(int unit){
	int sel;
	int createmode,drive;
	extern int scr_size_L,scr_size_C;
	enum kind_t tmpkind[21];
	int tmpunit[21],disktype;
	if(FDflag[unit]==FD_FILE){
		sel=selectitem(" NONE  DRIVE0 DRIVE1  FILE   NEW   EJECT  WRITE  ",7,7,0);
	}else{
		sel=selectitem(" NONE  DRIVE0 DRIVE1  FILE   NEW   EJECT          ",7,6,0);
	}
	if(FDflag[unit]==FD_FILE)fde_savedisk(unit,0);
	switch(sel){
	case 0:
		FDflag[unit]=FD_NONE;
		break;
	case 1:
		FDflag[unit]=FD_DRV0;
		break;
	case 2:
		FDflag[unit]=FD_DRV1;
		break;
	case 3:
		if(selectfile(FDfname[unit])){
			FDflag[unit]=FD_EJECT;
			fde_setconfig();
			FDflag[unit]=FD_FILE;
			fde_loaddisk(unit);
		}
		break;
	case 4:
		s_locate(scr_size_L-1,0);
		s_puts("File name:                                        ");
		s_locate(scr_size_L-1,10);
		strinput(FDfname[unit],_MAX_LFN,scr_size_C-12);
		s_locate(scr_size_L-1,0);
		s_clrline();
		if(strlen(FDfname[unit])){
			if((disktype=selectFDtype())<0){
				s_clrline();
				break;
			}
			s_clrline();
			if((createmode=selectcreatemode())<0){
				s_clrline();
				break;
			}
		}
		if(disktype<0 || createmode<0)break;
		s_locate(scr_size_L-1,0);
		s_clrline();
		if(strlen(FDfname[unit]) && disktype>=0){
			create_d88(FDfname[unit],disktype);
			FDflag[unit]=FD_FILE;
		}
		if(createmode){
			if(!fde_readcopy(createmode-1,unit,disktype))
				fde_savedisk(unit,1);
		}else fde_loaddisk(unit);
		break;
	case 5:
		FDflag[unit]=FD_EJECT;
		break;
	case 6:
		s_clrline();
		if((drive=selectFDunit())<0){
			s_clrline();
			break;
		}
		s_clrline();
		fde_writecopy(drive,unit);
		break;
	default:
		break;
	}
	showlist(tmpkind,tmpunit);
	showconfline();
	fde_setconfig();
}

void selectHDD(int unit){
	int sel;
	extern int scr_size_L,scr_size_C;
	enum kind_t tmpkind[21];
	int tmpunit[21];
	sel=selectitem(" NONE  FILE  NEW                                  ",6,3,0);
	switch(sel){
	case 0:
		HDflag[unit]=HD_NONE;
		break;
	case 1:
		if(selectfile(HDfname[unit]))HDflag[unit]=HD_FILE;
		break;
	case 2:
		HDflag[unit]=HD_FILE;
		s_locate(scr_size_L-1,0);
		s_puts("File name:                                        ");
		s_locate(scr_size_L-1,10);
		strinput(HDfname[unit],_MAX_LFN,scr_size_C-12);
		s_locate(scr_size_L-1,0);
		s_clrline();
		break;
	default:
		break;
	}
	showlist(tmpkind,tmpunit);
	showconfline();
}

int selectFDtype(void){
	int type;
	type=selectitem("  2D       2DD    2HD(NEC) 2HD(IBM) ",9,4,0);
	return type;
}

int selectcreatemode(void){
	int mode;
	mode=selectitem(" Blank   DRIVE0  DRIVE1 ",8,3,0);
	return mode;
}

int selectFDunit(void){
	int drive;
	drive=selectitem(" DRIVE0  DRIVE1 ",8,2,0);
	return drive;
}

int create_d88(char *filename,int type){
	FIL file;
	int i,C,H,trackside,sect,tracksize,imgsize,len;
	static const int tracks[]={84,164,164,164};
//	static const int tracklen[]={6250,6250,10416,12500};
	static const int blocks[]={13,13,21,25};
	static const int headsize=0x2b0;
	char buf[512+16],*buf2=&buf[16];
	volatile alt_irq_context ic;
	ic=alt_irq_disable_all();
	if(f_open(&file,filename,FA_WRITE | FA_CREATE_ALWAYS)!=FR_OK){
		alt_irq_enable_all(ic);
		return -1;
	}
	for(i=0;i<26;i++)buf[i]=0x00;
	buf[26]=0x00;
	buf[27]=(char)((type<<4)&0xff);
	tracksize=512*blocks[type];
	imgsize=headsize+tracksize*tracks[type];
	buf[28]=(char)(imgsize & 0x0ff);
	buf[29]=(char)((imgsize>>8)& 0x0ff);
	buf[30]=(char)((imgsize>>16)& 0x0ff);
	buf[31]=(char)((imgsize>>24)& 0x0ff);
	f_write(&file,buf,32,&len);
	imgsize=headsize;
	for(trackside=0;trackside<164;trackside++){
		if(trackside<tracks[type]){
			buf[0]=(char)(imgsize & 0x0ff);
			buf[1]=(char)((imgsize>>8)& 0x0ff);
			buf[2]=(char)((imgsize>>16)& 0x0ff);
			buf[3]=(char)((imgsize>>24)& 0x0ff);
			imgsize+=512*blocks[type];
		}else{
			buf[0]=0x00;
			buf[1]=0x00;
			buf[2]=0x00;
			buf[3]=0x00;
		}
		f_write(&file,buf,4,&len);
	}
	for(trackside=0;trackside<tracks[type];trackside++){
		printgauge(trackside,tracks[type],0x60);
		C=trackside>>1;
		H=trackside&0x01;
		buf[0]=(char)C;
		buf[1]=(char)H;
		buf[2]=0x01;	//R
		buf[3]=0x01;	//N
		buf[4]=0x01;	//number of sectors/track
		buf[5]=0x00;
		for(i=6;i<14;i++)buf[i]=0x00;
		buf[14]=0x00;
		buf[15]=0x01;
		for(i=0;i<512;i++)buf2[i]=0x4e;
		f_write(&file,buf,512,&len);
		for(i=1;i<blocks[type];i++)f_write(&file,buf2,512,&len);
	}
	cleargauge();
	f_close(&file);
	alt_irq_enable_all(ic);
	return 0;
}

void selectSRAM(void){
	int sel;
	extern int scr_size_L,scr_size_C;
	enum kind_t tmpkind[21];
	int tmpunit[21];
	sel=selectitem(" STORE LOAD  FILE  NEW                            ",6,4,0);
	switch(sel){
	case 0:
		savesram();
		break;
	case 1:
		loadsram();
		break;
	case 2:
		selectfile(SRAMfname);
		break;
	case 3:
		s_locate(scr_size_L-1,0);
		s_puts("File name:                                        ");
		s_locate(scr_size_L-1,10);
		strinput(SRAMfname,_MAX_LFN,scr_size_C-12);
		s_locate(scr_size_L-1,0);
		s_clrline();
		savesram();
		break;
	default:
		break;
	}
	showlist(tmpkind,tmpunit);
	showconfline();
}
int strinput(char *str,int len,int linelen){
	int i=0,j,endflag;
	char c,*buf;
	buf=(char *)malloc((len+1)*sizeof(char));
	s_cursoren(1);
	do{
		s_setcursor();
		endflag=0;
		c=keyin();
		switch(c){
		case KEY_BS:
			if(i>0){
				i--;
				if(i>=linelen){
					for(j=0;j<linelen;j++)s_curleft();
					for(j=0;j<linelen;j++)s_putc(buf[i-linelen+j]);
				}else{
					s_curleft();
					s_putc(' ');
					s_curleft();
				}
			}
			break;
		case KEY_ESC:
			endflag=1;
			break;
		case '\n':
			buf[i]='\0';
			endflag=1;
			break;
		case '\t':
		case KEY_UP:
		case KEY_DOWN:
		case KEY_LEFT:
		case KEY_RIGHT:
			break;
		default:
			if(i<len && isprint(c)){
				buf[i]=c;
				i++;
				if(i>linelen){
					for(j=0;j<linelen;j++)s_curleft();
					for(j=0;j<linelen;j++)s_putc(buf[i-linelen+j]);
				}else{
					s_putc(c);
				}
			}
			break;
		}
	}while(!endflag);
	s_cursoren(0);
	if(c==KEY_ESC){
		free(buf);
		return -1;
	}
	if(c=='\n'){
		strcpy(str,buf);
		free(buf);
		return i;
	}
	free(buf);
	return 0;
}

int selectfile(char *fname){
	int i,listnum,pagenum,page,listnew;
	extern int scr_size_L;
	char path[_MAX_LFN+1]="",tmp_path[_MAX_LFN+1],selfname[_MAX_LFN+1],key;
	for(i=3;i<scr_size_L;i++){
		s_locate(i,0);
		s_clrline();
	}
	pagenum=scr_size_L-5;
	page=0;
	i=0;
	while(1){
		listnum=show_dirlist(path,pagenum,page);
		listnew=0;
		setline(i+1,0x60);
		do{
			key=keyin();
			switch(key){
			case KEY_UP:
				setline(i+1,isdir[i]?0x06:0x07);
				if(i>0)i--;
				else if(page>0){
					page--;
					i=pagenum-1;
					listnew=1;
				}
				setline(i+1,0x60);
				break;
			case KEY_DOWN:
				setline(i+1,isdir[i]?0x06:0x07);
				if(i<listnum-1)i++;
				else if(listnum==pagenum){
					page++;
					i=0;
					listnew=1;
				}
				setline(i+1,0x60);
				break;
			case KEY_RIGHT:
				if(listnum==pagenum){
					page++;
					i=0;
					listnew=1;
				}
				break;
			case KEY_LEFT:
				if(page>0){
					page--;
					i=0;
					listnew=1;
				}
				break;
			case ' ':
			case '\n':
				selectfilename(path,page*pagenum+i,selfname);
				sprintf(tmp_path,"%s/%s",path,selfname);
				if(isdir[i]){
					strcpy(path,tmp_path);
					page=0;
					i=0;
					listnew=1;
				}else{
					strcpy(fname,tmp_path);
					return 1;
				}
				break;
			case KEY_ESC:
				return 0;
				break;
			default:
				break;
			}
		}while(!listnew);
	}
}

int show_dirlist(char *path,int count,int num){
	int i,j,k,pagenum;
	FRESULT res;
	extern int scr_size_C;
	DIR dir;
	FILINFO fno;
	char *fname;
	static char lfname[_MAX_LFN+1];
	volatile alt_irq_context ic;
	fno.lfname=lfname;
	fno.lfsize=sizeof lfname;
	s_setdattr(0x40);
	s_locate(3,1);
	s_puts("PATH:");
	if(strlen(path)>scr_size_C-6)s_puts(&path[strlen(path)-scr_size_C+6]);
	else s_puts(path);
	s_setdattr(0x07);
	s_newline();
	ic=alt_irq_disable_all();
	if(f_opendir(&dir,path)!=FR_OK){
		alt_irq_enable_all(ic);
		return -1;
	}
	for(i=0;i<count;i++){
		s_locate(4+i,0);
		s_clrline();
	}
	i=0;
	for(j=0;j<num;j++)for(k=0;k<count;k++){
		res=f_readdir(&dir,&fno);
		if(res!=FR_OK || fno.fname[0]==0){
			alt_irq_enable_all(ic);
			return 0;
		}
	}
	s_locate(4,0);
	do{
		res=f_readdir(&dir,&fno);
		if(res!=FR_OK ||fno.fname[0]==0)break;
//		if(fno.fname[0]=='.')continue;
		fname=*fno.lfname?fno.lfname:fno.fname;
		isdir[i]=(fno.fattrib & AM_DIR)?1:0;
		s_setdattr(isdir[i]?0x06:0x07);
		s_putc(' ');
		fname[scr_size_C-3]='\0';
		s_puts(fname);
		s_newline();
		i++;
	}while(i<count);
	alt_irq_enable_all(ic);
	return i;
}

int selectfilename(char *path,int num,char *filename){
	int i;
	DIR dir;
	FILINFO fno;
	char *fname;
	static char lfname[_MAX_LFN+1];
	volatile alt_irq_context ic;
	fno.lfname=lfname;
	fno.lfsize=sizeof lfname;
	ic=alt_irq_disable_all();
	f_opendir(&dir,path);
	for(i=0;i<=num;i++)f_readdir(&dir,&fno);
	alt_irq_enable_all(ic);
	fname=*fno.lfname?fno.lfname:fno.fname;
	strcpy(filename,fname);
}

