/*
 * crccalc.h
 */

#ifndef CRCCALC_H_
#define CRCCALC_H_

void crcclr(int x);
void crcinit(int len,int clrdat,int poly);
int crccalc(int dat);
int crcget(void);
#endif /* CRCCALC_H_ */
