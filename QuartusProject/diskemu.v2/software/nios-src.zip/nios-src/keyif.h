/*
 * keyif.h
 */

#ifndef KEYIF_H_
#define KEYIF_H_

#include "system.h"
#include "altera_avalon_pio_regs.h"

#define KEY_UP		0x1e
#define KEY_DOWN	0x1f
#define KEY_LEFT	0x1d
#define KEY_RIGHT	0x1c
#define KEY_ESC		0x1b
#define	KEY_BS		0x08

void ini_kb(void);
void rxkey(void);

#endif /* KEYIF_H_ */
